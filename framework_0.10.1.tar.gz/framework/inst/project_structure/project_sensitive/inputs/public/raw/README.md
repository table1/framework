# Raw (Public)

**PUBLIC DATA - SAFE TO COMMIT**

- Store public datasets as delivered (census data, public health statistics, lookup tables).
- Examples: ICD code mappings, ZIP code databases, publicly available comparison datasets.
- Files here can be committed to version control.
