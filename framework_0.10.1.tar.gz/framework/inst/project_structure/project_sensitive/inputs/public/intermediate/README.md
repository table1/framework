# Intermediate (Public)

**PUBLIC DATA - SAFE TO COMMIT**

- Cleaned or transformed public datasets.
- Fully de-identified data ready for sharing.
- Files here can be committed to version control.
