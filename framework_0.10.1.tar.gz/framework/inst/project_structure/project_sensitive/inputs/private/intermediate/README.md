# Intermediate (Private)

**SENSITIVE DATA - NOT COMMITTED TO GIT**

- Store cleaned, merged, or transformed datasets that still contain sensitive information.
- Intermediate processing steps before final de-identification.
- This directory is gitignored by default - never contains public data.
