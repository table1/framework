# Final (Private)

**SENSITIVE DATA - NOT COMMITTED TO GIT**

- Analysis-ready datasets that still contain sensitive/identifiable information.
- Used directly in notebooks and scripts for analysis.
- This directory is gitignored by default - never contains public data.
