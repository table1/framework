# Reference (Public)

**PUBLIC MATERIALS - SAFE TO COMMIT**

- Store public reference materials: published codebooks, public data dictionaries, background papers.
- Documentation that can be shared openly.
- Files here can be committed to version control.
