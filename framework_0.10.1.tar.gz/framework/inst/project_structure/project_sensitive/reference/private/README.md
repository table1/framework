# Reference (Private)

**SENSITIVE MATERIALS - NOT COMMITTED TO GIT**

- Store sensitive reference materials: IRB protocols, proprietary codebooks, confidential data dictionaries.
- Background documents containing sensitive information.
- This directory is gitignored by default.
