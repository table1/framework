# Outputs (Public)

**PUBLIC RESULTS - SAFE TO COMMIT**

- Fully de-identified, sanitized outputs ready for external sharing.
- Examples: aggregate tables, redacted figures, publishable models, final reports.
- Only place outputs here after explicit review and approval.
- Files here can be committed to version control.
