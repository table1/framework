# Outputs (Private)

**SENSITIVE RESULTS - NOT COMMITTED TO GIT**

- Default home for all working artifacts: tables, figures, models, notebooks, cache.
- Anything here is assumed to contain sensitive or identifiable information.
- Only promote de-identified, sanitized deliverables to `outputs/public/` when ready to share.
- This directory is gitignored by default.
