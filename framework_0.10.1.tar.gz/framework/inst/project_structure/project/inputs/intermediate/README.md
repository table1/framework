# Intermediate

- Place cleaned or reshaped datasets that are still considered inputs to later work.
- Track major transformations in a changelog or notebook so the lineage is clear.
- Promote curated tables to `inputs/final/` once they are ready for analysis.
