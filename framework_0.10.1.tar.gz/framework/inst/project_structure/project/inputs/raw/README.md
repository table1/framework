# Raw

- Store source data exactly as delivered (CSV extracts, database dumps, ZIP files).
- Keep original filenames; add a companion note if you received multiple versions.
- Do not edit files in place—create derived copies in `inputs/intermediate/`.
