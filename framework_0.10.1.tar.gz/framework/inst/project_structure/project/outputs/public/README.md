# Outputs (Public)

- Move or copy artifacts here only after privacy and compliance checks.
- Keep filenames aligned with their private counterparts for traceability.
- Include context (data sources, refresh dates) in an accompanying Markdown note when publishing.
