# Outputs (Private)

- Default home for working artifacts: tables, figures, models, notebooks, cache.
- Anything here is assumed to contain sensitive or preliminary content.
- Promote sanitized deliverables to `outputs/public/` when they are ready to share externally.
