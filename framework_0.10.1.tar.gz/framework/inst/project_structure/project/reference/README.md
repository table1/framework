# Reference Materials

- Store codebooks, protocols, memos, and other external documentation that ships with the data.
- Use descriptive filenames and note the source or version when possible.
- If documents live elsewhere (e.g., client portal), drop a Markdown stub with links here.
