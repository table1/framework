# Slides

- Author lecture decks here (Quarto `.qmd`, PowerPoint, PDF, etc.).
- Use consistent naming such as `lecture-05-linear-models.qmd` so exports stay organized.
- Rendered outputs default to `slides/_rendered/{{ slug }}.{ext}` (e.g., `slides/_rendered/day1-slides.html`).
