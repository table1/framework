# Course Docs

- Store syllabus, policies, grading schemes, and other instructor-authored references.
- Use dated filenames (`2025-01-09-syllabus.md`) to track revisions over the term.
- Link to living documents (LMS, shared drives) when they are the canonical source.
