# Readings

- Collect assigned readings, slide exports from guest lectures, and external PDFs.
- When materials are licensed or hosted elsewhere, create a short Markdown file with the citation and access link.
- Group by module (`unit_02/`, `week05/`) if the list grows large.
