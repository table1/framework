# Data Directory

- Store shared datasets that students use across the course.
- Organize by theme or module when helpful (e.g., `unit_01/`).
- Keep raw source files here; lecture-specific copies can live alongside the lecture materials.
