# Assignments

- Create one subfolder per assignment (e.g., `hw01/`, `lab03/`).
- Include the prompt, starter files, and any solutions or rubrics.
- Generated deliverables from students should live outside the repository or in a synced LMS.
