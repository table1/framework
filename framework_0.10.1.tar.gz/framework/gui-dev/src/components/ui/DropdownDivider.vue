<template>
  <div class="my-1 h-px bg-gray-100 dark:bg-white/10"></div>
</template>

<script setup>
// Simple divider component for dropdowns
</script>
