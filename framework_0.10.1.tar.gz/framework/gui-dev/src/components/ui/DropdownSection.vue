<template>
  <div class="py-1">
    <slot />
  </div>
</template>

<script setup>
// Section wrapper for grouped dropdown items
</script>
