#!/usr/bin/env Rscript
# {{ title }}
# Created: {{ date }}

# Load project environment
library(framework)
scaffold()

# Your code here
