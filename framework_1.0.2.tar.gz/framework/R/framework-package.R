#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom grDevices dev.cur dev.list dev.off png
#' @importFrom stats na.omit
#' @importFrom utils capture.output head install.packages modifyList object.size packageVersion sessionInfo str write.table
## usethis namespace: end
NULL
