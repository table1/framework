#!/usr/bin/env Rscript
# {filename}
# Created: {date}

# Load project environment
library(framework)
scaffold()

# Your code here
