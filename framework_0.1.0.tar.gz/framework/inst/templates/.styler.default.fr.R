function(...) {
  styler::tidyverse_style(
    indent_by = 2,
    start_comments_with_one_space = TRUE
  )
}
